<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	
<div class="content">
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>
    <?php  if (isset($_SESSION['username'])) : ?>
    	<p id="name">
        Welcome <strong><?php echo $_SESSION['username']; ?></strong>   
      </p>
    	<p> <a href="logged.php?logout='1'" style="color: red;">logout</a> 
      <a id="back"href="index.html">Back to home</a>
     </p>
    <?php endif ?>
</div>

<form id="quizForm">
    <h2>Въпрос 1:</h2>
    <p>Каква е столицата на Франция?</p>
    <label>
      <input type="radio" name="q1" value="a"> А) Париж
    </label>
    <br>
    <label>
      <input type="radio" name="q1" value="b"> Б) Лондон
    </label>
    <br>
    <label>
      <input type="radio" name="q1" value="c"> В) Рим
    </label>

    <h2>Въпрос 2:</h2>
    <p>Кой от изброените градове се намира в Испания?</p>
    <label>
      <input type="radio" name="q2" value="a"> А) Париж
    </label>
    <br>
    <label>
      <input type="radio" name="q2" value="b"> Б) Лондон
    </label>
    <br>
    <label>
      <input type="radio" name="q2" value="c"> В) Мадрид
    </label>

    <br>
    <button type="button" onclick="checkAnswers()">Изпрати</button>
  </form>

  <div id="result"></div>

  <script>
    function checkAnswers() {
      var quizForm = document.getElementById("quizForm");
      var score = 0;
      var q1Answer = quizForm.elements["q1"].value;
      if (q1Answer === "a") {
        score++;
      }
      var q2Answer = quizForm.elements["q2"].value;
      if (q2Answer === "c") {
        score++;
      }
      alert("Брой правилно отговорени въпроси: " + score);
    }
  </script>
</body>
</html>